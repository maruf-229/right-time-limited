<div class="topbar">
    <div class="container-fluid">
        <p class="topbar__text">Welcome to Right Time Limited</p>
        <ul class="topbar__info">
            

            <?php if(request()->is('/')): ?>
                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:info@righttime.biz">info@righttime.biz</a>
                </li>
                <li>
                    <i class="fa fa-map-marker"></i>
                    Level: 06 & 14 (west), BDBL Bhaban, 12, Karwan Bazar, Tejgaon
                </li>
            <?php elseif(request()->is('usa')): ?>
                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:info@righttime.biz">coo.usa@righttime.biz</a>
                </li>
                <li>
                    <i class="fa fa-map-marker"></i>
                    14108 Hamlin Street, Unit # 7, Van Nuys, CA-91401
                </li>
            <?php elseif(request()->is('aus')): ?>
                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:info@righttime.biz">coo.au@righttime.biz</a>
                </li>
                <li>
                    <i class="fa fa-map-marker"></i>
                    11 Dahlia St. Quakers Hill,NSW 2763,Sydney,Australia.
                </li>
            <?php elseif(request()->is('de')): ?>
                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:info@righttime.biz">coo.de@righttime.biz</a>
                </li>
                <li>
                    <i class="fa fa-map-marker"></i>
                    Hausmann str-1.44139,Dortmund. Germany
                </li>
            <?php endif; ?>







            <li>
                <div class="dropdown">
                    <div class="dropbtn">Countries <i class="fa fa-solid fa-square-caret-down" style="padding-top: 10px"></i></div>
                    <div class="dropdown-content">
                        <a href="<?php echo e(url('/usa/')); ?>">USA</a>
                        <a href="<?php echo e(url('/aus/')); ?>">Australia</a>
                        <a href="<?php echo e(url('/de/')); ?>">Germany</a>
                    </div>
                </div>
            </li>

        </ul><!-- /.topbar__info -->

    </div><!-- /.container-fluid -->
</div><!-- /.topbar -->
<nav class="main-menu sticky-header">
    <div class="container-fluid">
        <div class="main-menu__logo">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('frontend/assets/images/images-removebg-preview.png')); ?>" width="88" height="75" alt="Cretech">
            </a>
        </div><!-- /.main-menu__logo -->

        <ul class="main-menu__list">
            <li>
                <a href="<?php echo e(url('/')); ?>">Home</a>
            </li>
            <li >
                <a href="<?php echo e(url('/about-us')); ?>">About Us</a>




            </li>

            <li class="menu-item-has-children">
                <a href="<?php echo e(url('/industries')); ?>">Industries</a>
                <ul>
                    <li><a href="<?php echo e(url('/industries/bank-nbfi')); ?>">Bank & NBFI</a></li>
                    <li><a href="<?php echo e(url('/industries/telecommunications')); ?>">Telecommunications</a></li>
                    <li><a href="<?php echo e(url('/industries/pci')); ?>">Payment Card Industry</a></li>
                    <li><a href="<?php echo e(url('/industries/educational-institutions')); ?>">Educational Institutions</a></li>
                    <li><a href="<?php echo e(url('/industries/erm')); ?>">eCommerce & Retail Merchants</a></li>
                    <li><a href="<?php echo e(url('/industries/health-care')); ?>">Health Care</a></li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(url('/partners')); ?>">Partners</a>
            </li>


            <li class="menu-item-has-children-s menu-item-has-children">
                <a href="<?php echo e(url('/services')); ?>">Services</a>
                <ul>
                <div class="service-dropdown-mega-menu">
                    <li>
                        <div class="inner-mega-menu">
                            <a href="<?php echo e(url('/services/consultation')); ?>">Consultation</a>
                            <a href="<?php echo e(url('/services/consultation/information-security')); ?>"><p>Information Security-Specially Cyber Security Consulting</p></a>
                            <a href="<?php echo e(url('/services/consultation/partners-management')); ?>" ><p>Project Management</p></a>
                            <a href="<?php echo e(url('/services/consultation/providing-security')); ?>"><p>Providing Security</p></a>
                            <a href="<?php echo e(url('/services/consultation/DC-DRS')); ?>"><p>Consultation on Shaping the DC & DRS</p></a>
                            <a href="<?php echo e(url('/services/consultation/swift-cyber-security-consulting')); ?> "><p>Swift Cyber Security Consulting</p></a>
                            <a href="<?php echo e(url('/services/consultation/technical-documentation-on-ICT')); ?> "><p>Technical Documentation on ICT</p></a>
                        </div>
                    </li>

                    <li>
                        <div class="inner-mega-menu">
                            <a href="<?php echo e(url('/services/auditing')); ?>">Auditing</a>
                            <a href="<?php echo e(url('/services/consultation')); ?>" ><p>Information System Audit</p></a>
                            <a href="<?php echo e(url('/services/auditing')); ?>" ><p>Information Technology Audit</p></a>
                            <a href="<?php echo e(url('/services/security-assessment-testing')); ?>"><p>Information Security Graded Audit</p></a>
                            <a href="<?php echo e(url('/services/standard-implementation-certification')); ?>" ><p>DC & DRS Auditing</p></a>
                        </div>
                    </li>

                    <li>
                        <div class="inner-mega-menu">
                            <a href="<?php echo e(url('/services/security-assessment-testing')); ?>" >Security Testing</a>
                            <a href="<?php echo e(url('/services/security-assessment-testing/')); ?>" ><p>Security Assessment & Testing</p></a>
                            <a href="<?php echo e(url('/services/security-assessment-testing/VAPT')); ?>"><p>Vulnerability Assessment & Presentation Testing Services</p></a>
                            <a href="<?php echo e(url('/services/security-assessment-testing/digital-forensics')); ?>"><p>Digital Forensics</p></a>
                            <a href=""><p>Code Review</p></a>
                        </div>
                    </li>

                    <li>
                        <div class="inner-mega-menu">
                            <a href="<?php echo e(url('/services/standard-implementation-certification')); ?>">Certification</a>
                            <a href="<?php echo e(url('/services/standard-implementation-certification/pci-dss')); ?>" ><p>Payment Card Industry Data Security Standards</p></a>
                            <a href="<?php echo e(url('/services/standard-implementation-certification/iso')); ?>" ><p>International Organization for Standardization-ISO</p></a>
                            <a href="<?php echo e(url('/services/standard-implementation-certification/CMMI')); ?>"><p>CMMI</p></a>
                            <a href="<?php echo e(url('/services/standard-implementation-certification/SCIA')); ?>" ><p>SWIFT CSP Independent Assesment</p></a>
                            <a href="<?php echo e(url('/services/standard-implementation-certification/')); ?>" ><p>TIA 942 for Data Center</p></a>
                        </div>
                    </li>


















                   <li>
                    <div class="inner-mega-menu">
                        <a href="<?php echo e(url('/services/solutions')); ?>">Solutions</a>
                        <a href="<?php echo e(url('/services/solutions/BURP-Suite')); ?>"><p>BURP Suite</p></a>
                        <a href="<?php echo e(url('/services/solutions/acunetix')); ?>" ><p>Acunetix</p></a>
                        <a href="<?php echo e(url('/services/solutions/net-sporker')); ?>"><p>Net Sporker</p></a>
                        <a href="<?php echo e(url('/services/solutions/core-impact')); ?>" ><p>Core Impact</p></a>
                        <a href="<?php echo e(url('/services/solutions/SIEM-solutions')); ?>" ><p>Core Impact</p></a>
                        <a href="<?php echo e(url('/services/solutions/firewall')); ?>" ><p>Firewall</p></a>
                        <a href="<?php echo e(url('/services/solutions/Bulk-SMS')); ?>" ><p>Bulk SMS</p></a>
                        <a href="<?php echo e(url('/services/solutions/smart-contract')); ?>" ><p>Smart Contract</p></a>
                    </div>
                   </li>



                </div>
            </ul>
            </li>


            <li>
                <a href="<?php echo e(url('/services/security-training')); ?>">Training</a>
            </li>

            <li >
                <a href="<?php echo e(url('/blog')); ?>">Careers</a>
            </li>









            <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
        </ul><!-- /.main-menu__list -->

        <div class="main-menu__right">
            <a href="#" class="mobile-nav__toggler">
                <span></span>
                <span></span>
                <span></span>
            </a>





                <?php if(request()->is('/')): ?>
                <a href="tel:+9288009860" class="main-menu__cta">
                    <i class="fa fa-phone-alt"></i>
                    <span class="main-menu__cta__text">
							<b>+88 01714-003040</b>
							Call Anytime
						</span><!-- /.main-menu__cta__text -->
                </a><!-- /.main-menu__cta -->
                <?php elseif(request()->is('usa')): ?>
                <a href="" class="main-menu__cta">
                    <i class="fa fa-phone-alt"></i>
                    <span class="main-menu__cta__text">
							<b>+xx xxxxxxxxxx</b>
							Call Anytime
						</span><!-- /.main-menu__cta__text -->
                </a><!-- /.main-menu__cta -->
                <?php elseif(request()->is('aus')): ?>
                <a href="" class="main-menu__cta">
                    <i class="fa fa-phone-alt"></i>
                    <span class="main-menu__cta__text">
							<b>+xx xxxxxxxxxx</b>
							Call Anytime
						</span><!-- /.main-menu__cta__text -->
                </a><!-- /.main-menu__cta -->
                <?php elseif(request()->is('de')): ?>
                <a href="" class="main-menu__cta">
                    <i class="fa fa-phone-alt"></i>
                    <span class="main-menu__cta__text">
							<b>+xx xxxxxxxxxx</b>
							Call Anytime
						</span><!-- /.main-menu__cta__text -->
                </a><!-- /.main-menu__cta -->
                <?php endif; ?>


        </div><!-- /.main-menu__right -->

    </div><!-- /.container-fluid -->
</nav><!-- /.main-menu -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/body/header.blade.php ENDPATH**/ ?>