<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('title'); ?>
        Home
    <?php $__env->stopSection(); ?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.aus.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/bd/privacy.blade.php ENDPATH**/ ?>