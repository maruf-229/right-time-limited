<input type="checkbox" <?php echo $attributes->merge(['class' => 'rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50']); ?>>
<?php /**PATH C:\xampp\htdocs\cs-partners\vendor\laravel\jetstream\src/../resources/views/components/checkbox.bank_nbfi.blade.php ENDPATH**/ ?>
