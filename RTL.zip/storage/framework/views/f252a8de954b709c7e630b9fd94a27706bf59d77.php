<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/page-header-bg-1-1.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="index.html">Home</a></li>
                <li>Service Details</li>
            </ul>
            <h2 class="page-header__title">Infrastructure Plan</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->

    <section class="section-padding--bottom section-padding--top service-details--page">
        <div class="container">
            <div class="row ">
                <div class="col-lg-8">
                    <div class="service-details__image">
                        <img src="<?php echo e(asset('frontend/assets/images/services/service-d-1.jpg')); ?>" alt="">
                    </div><!-- /.service-details__image -->
                    <h3 class="service-details__title">Business & Finance</h3><!-- /.service-details__title -->
                    <div class="service-details__content">
                        <p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui
                            dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt
                            explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet
                            finibus eros. Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the ndustry standard dummy text ever since the 1500s, when an
                            unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        <h4>When an unknown printer took a galley of type and scrambled it to make a type specimen
                            book.</h4>
                        <p>It has survived not only five centuries. Lorem Ipsum is simply dummy text of the new
                            design printng and type setting Ipsum take a look at our round. When an unknown printer
                            took a galley of type and scrambled it to make a type specimen book. It has survived not
                            only five centuries, but also the leap into electronic typesetting.</p>
                    </div><!-- /.service-details__content -->
                    <div class="row gutter-y-30 service-details__box-wrapper">
                        <div class="col-md-6 col-sm-12">
                            <div class="service-details__box">
                                <i class="service-details__box__icon icon-consulting"></i>
                                <div class="service-details__box__content">

                                    <h3 class="service-details__box__title">
                                        <a href="#">IT Consultant</a>
                                    </h3>
                                    <p class="service-details__box__text">There are many of of lorem Ipsum, but the
                                        majori have suffered.</p><!-- /.service-details__box__text -->
                                </div><!-- /.service-details__box__content -->
                            </div><!-- /.service-details__box -->
                        </div><!-- /.col-md-6 col-sm-12 -->
                        <div class="col-md-6 col-sm-12">
                            <div class="service-details__box">
                                <i class="service-details__box__icon icon-chip"></i>
                                <div class="service-details__box__content">
                                    <h3 class="service-details__box__title">
                                        <a href="#">IT Specialist</a>
                                    </h3>
                                    <p class="service-details__box__text">There are many of of lorem Ipsum, but the
                                        majori have suffered.</p><!-- /.service-details__box__text -->
                                </div><!-- /.service-details__box__content -->
                            </div><!-- /.service-details__box -->
                        </div><!-- /.col-md-6 col-sm-12 -->
                    </div><!-- /.row -->
                    <div class="row gutter-y-30">
                        <div class="col-md-6 col-sm-12">
                            <img src="<?php echo e(asset('frontend/assets/images/services/service-d-2.jpg')); ?>" class="service-details__sub-image"
                                 alt="">
                        </div><!-- /.col-md-6 -->
                        <div class="col-md-6 col-sm-12">
                            <div class="service-details__caption">
                                <h3 class="service-details__caption__title">Our Benefits</h3>
                                <!-- /.service-details__caption__title -->
                                <p class="service-details__caption__text">Duis aute irure dolor in reprehenderit in
                                    voluptate velit esse cillum.</p><!-- /.service-details__caption__text -->
                                <ul class="service-details__caption__list">
                                    <li>
                                        <i class="fa fa-check-circle"></i>
                                        Praesent efficitur quam sit amet
                                    </li>
                                    <li>
                                        <i class="fa fa-check-circle"></i>
                                        Nunc cursus dolor id purus euismod
                                    </li>
                                    <li>
                                        <i class="fa fa-check-circle"></i>
                                        Quisque tincidunt eros ac place viverra
                                    </li>
                                </ul><!-- /.service-details__caption__list -->
                            </div><!-- /.service-details__caption -->
                        </div><!-- /.col-md-6 col-sm-12 -->
                    </div><!-- /.row -->

                    <div class="row">
                        <div class="col-md-12">
                            <div class="accrodion-grp service-details__accrodion"
                                 data-grp-name="service-details__accrodion-1">
                                <!--Start Faq One Single-->
                                <div class="accrodion  wow fadeInUp" data-wow-delay="0ms">
                                    <div class="accrodion-title">
                                        <h4>Nulla eu nisi pellentesque, ultrices lorem eget, mattis dolo <span
                                                class="accrodion-icon"></span>
                                        </h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered
                                                alteration in some fo injected humour, or randomised words
                                                believable. Phasellus a rhoncus erat. Vivamus vel eros vitae est
                                                aliquet pellentesque vitae.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Faq One Single-->
                                <!--Start Faq One Single-->
                                <div class="accrodion active wow fadeInUp" data-wow-delay="0ms">
                                    <div class="accrodion-title">
                                        <h4>Praesent nec ante sed libero tempus rutrum<span
                                                class="accrodion-icon"></span></h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered
                                                alteration in some fo injected humour, or randomised words
                                                believable. Phasellus a rhoncus erat. Vivamus vel eros vitae est
                                                aliquet pellentesque vitae.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Faq One Single-->
                                <!--Start Faq One Single-->
                                <div class="accrodion  wow fadeInUp" data-wow-delay="0ms">
                                    <div class="accrodion-title">
                                        <h4>Integer et mi in eros commodo bibendum<span
                                                class="accrodion-icon"></span></h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered
                                                alteration in some fo injected humour, or randomised words
                                                believable. Phasellus a rhoncus erat. Vivamus vel eros vitae est
                                                aliquet pellentesque vitae.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Faq One Single-->
                                <!--Start Faq One Single-->
                                <div class="accrodion  wow fadeInUp" data-wow-delay="0ms">
                                    <div class="accrodion-title">
                                        <h4>Proin commodo turpis eu leo tempus varius<span
                                                class="accrodion-icon"></span>
                                        </h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered
                                                alteration in some fo injected humour, or randomised words
                                                believable. Phasellus a rhoncus erat. Vivamus vel eros vitae est
                                                aliquet pellentesque vitae.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Faq One Single-->
                            </div>
                        </div><!-- /.col-md-12 -->
                    </div><!-- /.row -->
                </div><!-- /.col-lg-8 -->
                <div class="col-lg-4 sidebar-column">
                    <div class="sidebar">
                        <div class="sidebar__item sidebar__item--category">
                            <h3 class="sidebar__title">Categories</h3><!-- /.sidebar__title -->
                            <ul class="sidebar__category">
                                <li><a href="service-cyber-security.html">Cyber Security</a></li>
                                <li><a href="service-it-management.html">IT Management</a></li>
                                <li><a href="service-qa-testing.html">QA & Testing</a></li>
                                <li><a href="service-infrastructure-plan.html">Infrastructure Plan</a></li>
                                <li><a href="service-it-consultent.html">IT Consultent</a></li>
                            </ul><!-- /.sidebar__category -->
                        </div><!-- /.sidebar__item -->
                        <div class="sidebar__item sidebar__item--cta">
                            <div class="sidebar__cta"
                                 style="background-image: url(<?php echo e(asset('frontend/assets/images/services/services-s-cta-1-1.jpg')); ?>)">
                                <i class="sidebar__cta__icon icon-phone-ringing"></i>
                                <h3 class="sidebar__cta__title">Have Tech Problems
                                    Contact Now</h3><!-- /.sidebar__cta__title -->
                                <p class="sidebar__cta__text">Call Anytime <br><a href="tel:+1-(246)333-0088">+ 1-
                                        (246) 333-0088</a></p>
                                <!-- /.sidebar__cta__text -->
                            </div><!-- /.sidebar__cta -->
                        </div><!-- /.sidebar__item -->
                        <div class="sidebar__item sidebar__item--btn">
                            <a href="#" class="thm-btn sidebar__btn"><span>Download our flyers</span></a>
                        </div><!-- /.sidebar__item -->
                    </div><!-- /.sidebar -->
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-partners\resources\views/frontend/services/infrustructure.bank_nbfi.blade.php ENDPATH**/ ?>
