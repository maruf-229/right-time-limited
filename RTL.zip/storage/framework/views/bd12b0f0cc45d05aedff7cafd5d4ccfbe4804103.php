<h3 class="sidebar__title">Solutions</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('/services/solutions/BURP-Suite')); ?>">BURP Suite</a></li>
    <li><a href="<?php echo e(url('/services/solutions/acunetix')); ?>">Acunetix</a></li>
    <li><a href="<?php echo e(url('/services/solutions/net-sporker')); ?>">Net Sporker</a></li>
    <li><a href="<?php echo e(url('/services/solutions/core-impact')); ?>">Core Impact</a></li>
    <li><a href="<?php echo e(url('/services/solutions/SIEM-solutions')); ?>">SIEM Solutions</a></li>
    <li><a href="<?php echo e(url('/services/solutions/firewall')); ?>">Firewall</a></li>
    <li><a href="<?php echo e(url('/services/solutions/Bulk-SMS')); ?>">Bulk SMS</a></li>
    <li><a href="<?php echo e(url('/services/solutions/smart-contract')); ?>">Smart Contract</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/bd/services/solutions/common.blade.php ENDPATH**/ ?>