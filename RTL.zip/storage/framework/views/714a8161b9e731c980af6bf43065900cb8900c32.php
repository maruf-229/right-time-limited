<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('title'); ?>
        Project
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/page-header-bg-1-1.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="index.html">Home</a></li>
                <li>Projects</li>
            </ul>
            <h2 class="page-header__title">Projects</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->

    <section class="section-padding--bottom section-padding--top">
        <div class="container">
            <div class="row gutter-y-30">
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="000ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-1.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="100ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-2.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="200ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-3.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="300ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-4.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="400ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-5.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="500ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-6.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
            </div><!-- /.row gutter-y-30 -->
        </div><!-- /.container -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-partners\resources\views/frontend/partners/partners.bank_nbfi.blade.php ENDPATH**/ ?>
