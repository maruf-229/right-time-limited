<h3 class="sidebar__title">Consultation</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('aus/services/consultation/information-security')); ?>">Information Security-Specially Cyber Security Consulting</a></li>
    <li><a href="<?php echo e(url('aus/services/consultation/partners-management')); ?>">Project Management</a></li>
    <li><a href="<?php echo e(url('aus/services/consultation/providing-security')); ?>">Providing Security</a></li>
    <li><a href="<?php echo e(url('aus/services/consultation/DC-DRS')); ?>">Consultation on Shaping the DC & DRS</a></li>
    <li><a href="<?php echo e(url('aus/services/consultation/swift-cyber-security-consulting')); ?>">Swift Cyber Security Consulting</a></li>
    <li><a href="<?php echo e(url('aus/services/consultation/technical-documentation-on-ICT')); ?>">Technical Documentation on ICT</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/aus/services/consultation/common.blade.php ENDPATH**/ ?>