<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title'); ?>
        Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/page-header-bg-1-1.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                <li><a href="<?php echo e(url('/services/security-training')); ?>">Security Training</a></li>
                <li>Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools</li>
            </ul>
            <h2 class="page-header__title">Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->

    <section class="section-padding--bottom section-padding--top">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">


                    <h3 class="blog-card-one__title blog-details__title">Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools</h3>
                    <div class="blog-details__content">
                        <p>The Advanced Penetration Testing training provides all the advanced skills required to
                            carry out a thorough and professional penetration test against modern networks and infrastructure,
                            such as the ability to execute state-sponsored-like operations and advanced adversary simulations.
                            <br><br>
                            You must be familiar with PowerShell scripting, Active Directory administration and Windows
                            internals knowledge, basic reverse engineering skills, and possess a good working knowledge of
                            network protocols, as the content dives into all stages of a red-teaming engagement.
                            <br><br>
                            Right Time Limited offers approachable, hands-on vulnerability analysis and penetration testing
                            course to help you keep your networks safe from cyber criminals and launch your career in the
                            professional marketplace, whether you're interested in getting your first IT security job,
                            turning into a full-time white hat hacker, or getting ready to test the security of your own
                            home network.
                            <br><br>
                            We will also demonstrate about how to use licensed tools such as  Acunetix, BurpSuite,
                            Core Impact, Cobalt Strike, Nessus, Metasploit, etc.

                        </p>
                    </div><!-- /.blog-details__content -->


                </div><!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    <div class="sidebar">
                        <div class="sidebar__item sidebar__item--category">
                            <?php echo $__env->make('frontend.services.st.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div><!-- /.sidebar__item -->
                    </div><!-- /.sidebar -->
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-partners\resources\views/frontend/services/st/pt.blade.php ENDPATH**/ ?>
