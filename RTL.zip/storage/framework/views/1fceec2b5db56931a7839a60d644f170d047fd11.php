<div class="topbar">
    <div class="container-fluid">
        <p class="topbar__text">Welcome to Right Time Limited <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="30" zoomAndPan="magnify" viewBox="0 0 30 30.000001" height="30" preserveAspectRatio="xMidYMid meet" version="1.0"><defs><clipPath id="id1"><path d="M 2.933594 5.808594 L 26.886719 5.808594 L 26.886719 23.226562 L 2.933594 23.226562 Z M 2.933594 5.808594 " clip-rule="nonzero"/></clipPath><clipPath id="id2"><path d="M 7 7 L 26.886719 7 L 26.886719 22 L 7 22 Z M 7 7 " clip-rule="nonzero"/></clipPath><clipPath id="id3"><path d="M 2.933594 5.808594 L 16 5.808594 L 16 15 L 2.933594 15 Z M 2.933594 5.808594 " clip-rule="nonzero"/></clipPath><clipPath id="id4"><path d="M 3 5.808594 L 16 5.808594 L 16 15 L 3 15 Z M 3 5.808594 " clip-rule="nonzero"/></clipPath></defs><g clip-path="url(#id1)"><path fill="rgb(0%, 14.118958%, 49.01886%)" d="M 24.21875 5.808594 L 5.601562 5.808594 C 5.464844 5.808594 5.332031 5.816406 5.203125 5.835938 L 5.199219 7.011719 L 3.382812 7.007812 C 3.105469 7.433594 2.945312 7.941406 2.945312 8.488281 L 2.945312 20.546875 C 2.945312 22.027344 4.132812 23.226562 5.601562 23.226562 L 24.21875 23.226562 C 25.6875 23.226562 26.878906 22.027344 26.878906 20.546875 L 26.878906 8.488281 C 26.878906 7.007812 25.6875 5.808594 24.21875 5.808594 Z M 24.21875 5.808594 " fill-opacity="1" fill-rule="nonzero"/></g><g clip-path="url(#id2)"><path fill="rgb(100%, 100%, 100%)" d="M 8.925781 19.890625 L 8.113281 20.648438 L 8.195312 19.535156 L 7.101562 19.367188 L 8.015625 18.738281 L 7.464844 17.769531 L 8.519531 18.097656 L 8.925781 17.0625 L 9.332031 18.097656 L 10.390625 17.769531 L 9.839844 18.738281 L 10.753906 19.367188 L 9.660156 19.535156 L 9.738281 20.648438 Z M 21.523438 8.863281 L 20.992188 9.359375 L 21.046875 8.628906 L 20.332031 8.519531 L 20.929688 8.109375 L 20.566406 7.476562 L 21.257812 7.691406 L 21.523438 7.011719 L 21.792969 7.691406 L 22.484375 7.476562 L 22.121094 8.109375 L 22.71875 8.519531 L 22.003906 8.628906 L 22.058594 9.359375 Z M 18.867188 12.882812 L 18.335938 13.378906 L 18.386719 12.652344 L 17.671875 12.539062 L 18.269531 12.128906 L 17.910156 11.496094 L 18.601562 11.710938 L 18.867188 11.03125 L 19.132812 11.710938 L 19.824219 11.496094 L 19.464844 12.128906 L 20.0625 12.539062 L 19.34375 12.652344 L 19.398438 13.378906 Z M 24.847656 11.542969 L 24.316406 12.039062 L 24.371094 11.3125 L 23.65625 11.199219 L 24.253906 10.789062 L 23.890625 10.15625 L 24.582031 10.371094 L 24.847656 9.691406 L 25.117188 10.371094 L 25.808594 10.15625 L 25.445312 10.789062 L 26.042969 11.199219 L 25.328125 11.3125 L 25.382812 12.039062 Z M 21.523438 20.921875 L 20.992188 21.417969 L 21.046875 20.691406 L 20.332031 20.582031 L 20.929688 20.167969 L 20.566406 19.535156 L 21.257812 19.75 L 21.523438 19.070312 L 21.792969 19.75 L 22.484375 19.535156 L 22.121094 20.167969 L 22.71875 20.582031 L 22.003906 20.691406 L 22.058594 21.417969 Z M 23.554688 13.175781 L 23.75 13.574219 L 24.183594 13.640625 L 23.871094 13.949219 L 23.945312 14.390625 L 23.554688 14.183594 L 23.160156 14.390625 L 23.238281 13.949219 L 22.921875 13.640625 L 23.359375 13.574219 Z M 23.554688 13.175781 " fill-opacity="1" fill-rule="nonzero"/></g><g clip-path="url(#id3)"><path fill="rgb(0%, 14.118958%, 49.01886%)" d="M 15.574219 14.515625 L 15.574219 5.808594 L 5.601562 5.808594 C 5.390625 5.808594 5.203125 5.835938 5.203125 5.835938 L 5.199219 7.011719 L 3.382812 7.007812 C 3.382812 7.007812 3.355469 7.050781 3.300781 7.148438 C 3.074219 7.542969 2.945312 8 2.945312 8.488281 L 2.945312 14.515625 Z M 15.574219 14.515625 " fill-opacity="1" fill-rule="nonzero"/><path fill="rgb(93.328857%, 93.328857%, 93.328857%)" d="M 15.574219 5.808594 L 14.027344 5.808594 L 10.921875 7.996094 L 10.921875 5.808594 L 7.597656 5.808594 L 7.597656 7.527344 L 5.203125 5.835938 C 4.792969 5.898438 4.410156 6.054688 4.089844 6.28125 L 7.214844 8.488281 L 6.0625 8.488281 L 3.585938 6.738281 C 3.511719 6.824219 3.445312 6.914062 3.382812 7.007812 L 5.480469 8.488281 L 2.945312 8.488281 L 2.945312 11.835938 L 5.527344 11.835938 L 2.945312 13.691406 L 2.945312 14.515625 L 5.160156 14.515625 L 7.597656 12.796875 L 7.597656 14.515625 L 10.921875 14.515625 L 10.921875 12.328125 L 14.023438 14.515625 L 15.574219 14.515625 L 15.574219 13.15625 L 13.703125 11.835938 L 15.574219 11.835938 L 15.574219 8.488281 L 13.703125 8.488281 L 15.574219 7.167969 Z M 15.574219 5.808594 " fill-opacity="1" fill-rule="nonzero"/><path fill="rgb(81.17981%, 10.5896%, 16.859436%)" d="M 10.257812 5.808594 L 8.261719 5.808594 L 8.261719 9.15625 L 2.945312 9.15625 L 2.945312 11.167969 L 8.261719 11.167969 L 8.261719 14.515625 L 10.257812 14.515625 L 10.257812 11.167969 L 15.574219 11.167969 L 15.574219 9.15625 L 10.257812 9.15625 Z M 10.257812 5.808594 " fill-opacity="1" fill-rule="nonzero"/></g><g clip-path="url(#id4)"><path fill="rgb(81.17981%, 10.5896%, 16.859436%)" d="M 15.574219 5.808594 L 14.605469 5.808594 L 10.921875 8.40625 L 10.921875 8.488281 L 11.964844 8.488281 L 15.574219 5.941406 Z M 4.089844 6.28125 C 3.902344 6.414062 3.734375 6.566406 3.585938 6.738281 L 6.0625 8.488281 L 7.214844 8.488281 Z M 7.222656 11.835938 L 3.429688 14.515625 L 4.578125 14.515625 L 7.597656 12.386719 L 7.597656 11.835938 Z M 15.574219 14.382812 L 15.574219 13.566406 L 13.125 11.835938 L 11.964844 11.835938 Z M 15.574219 14.382812 " fill-opacity="1" fill-rule="nonzero"/></g></svg></p>
        <ul class="topbar__info">


                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:info@righttime.biz">coo.au@righttime.biz</a>
                </li>
                <li>
                    <i class="fa fa-map-marker"></i>
                    11 Dahlia St. Quakers Hill,NSW 2763,Sydney,Australia.
                </li>

            <li>
                <div class="dropdown">
                    <div class="dropbtn">Countries <i class="fa fa-solid fa-square-caret-down" style="padding-top: 10px"></i></div>
                    <div class="dropdown-content">
                        <a href="<?php echo e(url('/')); ?>">Bangladesh</a>
                        <a href="<?php echo e(url('/usa')); ?>">Usa</a>
                        <a href="<?php echo e(url('/de')); ?>">Germany</a>
                    </div>
                </div>
            </li>

        </ul><!-- /.topbar__info -->

    </div><!-- /.container-fluid -->
</div><!-- /.topbar -->


<nav class="main-menu sticky-header">
    <div class="container-fluid">
        <div class="main-menu__logo">
            <a href="<?php echo e(url('/aus')); ?>">
                <img src="<?php echo e(asset('frontend/assets/images/images-removebg-preview.png')); ?>" width="88" height="75" alt="Cretech">
            </a>
        </div><!-- /.main-menu__logo -->

        <ul class="main-menu__list">
            <li>
                <a href="<?php echo e(url('/aus')); ?>">Home</a>
            </li>
            <li >
                <a href="<?php echo e(url('aus/about-us')); ?>">About Us</a>
                
                
                
                
            </li>

            <li class="menu-item-has-children">
                <a href="<?php echo e(url('aus/industries')); ?>">Industries</a>
                <ul>
                    <li><a href="<?php echo e(url('aus/industries/bank-nbfi')); ?>">Bank & NBFI</a></li>
                    <li><a href="<?php echo e(url('aus/industries/telecommunications')); ?>">Telecommunications</a></li>
                    <li><a href="<?php echo e(url('aus/industries/pci')); ?>">Payment Card Industry</a></li>
                    <li><a href="<?php echo e(url('aus/industries/educational-institutions')); ?>">Educational Institutions</a></li>
                    <li><a href="<?php echo e(url('aus/industries/erm')); ?>">eCommerce & Retail Merchants</a></li>
                    <li><a href="<?php echo e(url('aus/industries/health-care')); ?>">Health Care</a></li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(url('aus/partners')); ?>">Partners</a>
                <ul>
                    <li><a href="#">Service Partner</a>
                        <ul>
                            <li><a href="https://www.eccouncil.org/">EC Council</a></li>
                            <li><a href="https://home.pearsonvue.com/" >Pearson Vue</a></li>
                            <li><a href="https://pecb.com/en">PECB ISO Certification</a></li>
                            <li><a href="https://arscert.com/certification/">ARS</a></li>
                            <li><a href="https://sckcerts.com/">SCK</a></li>
                            <li><a href="https://www.acnabin.com/">ACNABIN</a></li>
                        </ul>
                    </li>

                    <li><a href="#">Solution Partner</a>
                        <ul>
                            <li><a href="https://www.invicti.com/">INVICTI</a></li>
                            <li><a href="https://www.coresecurity.com/products/core-impact" >Core Impact</a></li>
                            <li><a href="https://portswigger.net/burp">Burp Suite</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Association</a>
                        <ul>
                            <li><a href="http://cca.gov.bd/site/office_head/5891f732-8e0f-40b0-9f85-1cb867657bfd/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A4">CCA,Ministry of ICT</a></li>
                            <li><a href="https://www.pcisecuritystandards.org/">PCI SSC, USA</a></li>
                            <li><a href="https://www.worldbank.org/en/home">WBGs (World Bank Group)</a></li>
                            <li><a href="https://www.swift.com/">SWIFT</a></li>
                            <li><a href="https://basis.org.bd/">BASIS</a></li>
                            <li><a href="https://e-cab.net/">E-CAB</a></li>
                        </ul>
                    </li>
                </ul>
            </li>





            <li class="menu-item-has-children">
                <a href="<?php echo e(url('aus/services')); ?>">Services</a>
                <ul>
                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/consultation')); ?>">Consultation</a>

                        <ul>
                            <li><a href="<?php echo e(url('aus/services/consultation/information-security')); ?>">Information Security-Specially Cyber Security Consulting</a></li>
                            <li><a href="<?php echo e(url('aus/services/consultation/partners-management')); ?>" >Project Management</a></li>
                            <li><a href="<?php echo e(url('aus/services/consultation/providing-security')); ?>">Providing Security</a></li>
                            <li><a href="<?php echo e(url('aus/services/consultation/DC-DRS')); ?>">Consultation on Shaping the DC & DRS</a></li>
                            <li><a href="<?php echo e(url('aus/services/consultation/swift-cyber-security-consulting')); ?> ">Swift Cyber Security Consulting</a></li>
                            <li><a href="<?php echo e(url('aus/services/consultation/technical-documentation-on-ICT')); ?> ">Technical Documentation on ICT</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/auditing')); ?>">Auditing</a>
                        <ul>
                            <li><a href="<?php echo e(url('aus/services/auditing/information-system-audit')); ?>">Information System Audit</a></li>
                            <li><a href="<?php echo e(url('aus/services/auditing/information-technology-audit')); ?>">Information Technology Audit</a></li>
                            <li><a href="<?php echo e(url('aus/services/auditing/information-security-graded-audit')); ?>">Information Security Graded Audit</a></li>
                            <li><a href="<?php echo e(url('aus/services/auditing/DC-DRS-audit')); ?>">DC & DRS Auditing</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/security-assessment-testing')); ?>" >Security Testing</a>
                        <ul>
                            <li><a href="<?php echo e(url('aus/services/security-assessment-testing/VAPT')); ?>">Vulnerability Assessment & Presentation Testing Services</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-assessment-testing/digital-forensics')); ?>">Digital Forensics</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-assessment-testing/code-review')); ?>">Code Review</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/standard-implementation-certification')); ?>">Certification</a>
                        <ul>
                            <li> <a href="<?php echo e(url('aus/services/standard-implementation-certification/pci-dss')); ?>" >Payment Card Industry Data Security Standards</a></li>
                            <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/iso')); ?>" >International Organization for Standardization-ISO</a></li>
                            <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/CMMI')); ?>">CMMI</a></li>
                            <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/SCIA')); ?>" >SWIFT CSP Independent Assesment</a></li>
                            <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/')); ?>" >TIA 942 for Data Center</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/solutions')); ?>">Solutions</a>
                        <ul>
                            <li><a href="<?php echo e(url('aus/services/solutions/BURP-Suite')); ?>">BURP Suite</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/acunetix')); ?>" >Acunetix</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/net-sporker')); ?>">Net Sporker</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/core-impact')); ?>" >Core Impact</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/SIEM-solutions')); ?>" >Core Impact</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/firewall')); ?>" >Firewall</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/Bulk-SMS')); ?>" >Bulk SMS</a></li>
                            <li><a href="<?php echo e(url('aus/services/solutions/smart-contract')); ?>" >Smart Contract</a></li>
                        </ul>
                    </li>

                </ul>
            </li>













            <li class="menu-item-has-children">
                <a href="<?php echo e(url('aus/services/security-training')); ?>">Training</a>
                <ul>
                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/security-training/assessment')); ?>">Assessment</a>
                        <ul>
                            <li><a href="<?php echo e(url('aus/services/security-training/assessment/ethical-hacker')); ?>">Certified Ethical Hacker (CEH)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/assessment/CPENT')); ?>">Certified Penetration Testing Professional(CPENT)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/assessment/CHFI')); ?>">Computer Hacking Forensic Investigator(CHFI)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/assessment/OSINT')); ?>">Open Source Intelligence(OSINT)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/assessment/GPEN')); ?>">GIAC Penetration Tester(GPEN)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/assessment/GWAPT')); ?>">GIAC Web Application Penetration Tester(GWAPT)</a></li>

                        </ul>
                    </li>

                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/security-training/management')); ?>">Management</a>
                        <ul>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CDRP')); ?>">Certified Disaster Recovery Professional</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CIH')); ?>">Certified Incident Handler</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CSA')); ?>">Certified SOC Analyst(CSA)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CTIA')); ?>">Certified Threat Intelligence Analyst(CTIA)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CISA')); ?>">Certified Information Systems Auditor(CISA)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CISM')); ?>">Certified Information Security Manager(CISM)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/CISSP')); ?>">Certified Information Systems Security Professional(CISSP)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/management/GCPM')); ?>">GIAC Certified Project Manager (GCPM)</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children"><a href="<?php echo e(url('aus/services/security-training/right-time-customized')); ?>">Customized</a>
                        <ul>
                            <li><a href="<?php echo e(url('aus/services/security-training/right-time-customized/basic')); ?>">Basic (Corporate)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/right-time-customized/advanced')); ?>">Advance (Corporate)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/right-time-customized/intermediate')); ?>">Intermediate (Corporate)</a></li>
                            <li><a href="<?php echo e(url('aus/services/security-training/right-time-customized/one-to-one-training')); ?>">One to One Training</a></li>

                        </ul>
                    </li>

                </ul>
            </li>













            <li >
                <a href="<?php echo e(url('aus/blog')); ?>">Careers</a>
            </li>

            
            
            
            
            
            
            

            <li><a href="<?php echo e(url('aus/contact')); ?>">Contact Us</a></li>
        </ul><!-- /.main-menu__list -->

        <div class="main-menu__right">
            <a href="#" class="mobile-nav__toggler">
                <span></span>
                <span></span>
                <span></span>
            </a>
            
            
            



            <a href="tel:+6149051754" class="main-menu__cta">
                <i class="fa fa-phone-alt"></i>
                <span class="main-menu__cta__text">
							<b>(+61) 490517545</b>
							Call Anytime
						</span><!-- /.main-menu__cta__text -->
            </a><!-- /.main-menu__cta -->








        </div><!-- /.main-menu__right -->

    </div><!-- /.container-fluid -->
</nav><!-- /.main-menu -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/aus/body/header.blade.php ENDPATH**/ ?>