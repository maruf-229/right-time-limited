<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('title'); ?>
        Partners
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/page-header-bg-1-1.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>Partners</li>
            </ul>
            <h2 class="page-header__title">Partners</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->

    <section class="section-padding--bottom section-padding--top">
        <div class="container">
            <div class="row gutter-y-30">
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="000ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/project-1-1.jpg')); ?>" alt="">
                        </div><!-- /.project-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.project-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.project-card-one__more -->
                            </div><!-- /.project-card-one__content__inner -->
                        </div><!-- /.project-card-one__content -->
                    </div><!-- /.project-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="100ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/project-1-2.jpg')); ?>" alt="">
                        </div><!-- /.project-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.project-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.project-card-one__more -->
                            </div><!-- /.project-card-one__content__inner -->
                        </div><!-- /.project-card-one__content -->
                    </div><!-- /.project-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="200ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/project-1-3.jpg')); ?>" alt="">
                        </div><!-- /.project-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.project-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.project-card-one__more -->
                            </div><!-- /.project-card-one__content__inner -->
                        </div><!-- /.project-card-one__content -->
                    </div><!-- /.project-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="300ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/project-1-4.jpg')); ?>" alt="">
                        </div><!-- /.project-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.project-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.project-card-one__more -->
                            </div><!-- /.project-card-one__content__inner -->
                        </div><!-- /.project-card-one__content -->
                    </div><!-- /.project-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="400ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/project-1-5.jpg')); ?>" alt="">
                        </div><!-- /.project-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.project-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.project-card-one__more -->
                            </div><!-- /.project-card-one__content__inner -->
                        </div><!-- /.project-card-one__content -->
                    </div><!-- /.project-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
                <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-duration="1500ms"
                     data-wow-delay="500ms">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/project-1-6.jpg')); ?>" alt="">
                        </div><!-- /.project-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.project-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.project-card-one__more -->
                            </div><!-- /.project-card-one__content__inner -->
                        </div><!-- /.project-card-one__content -->
                    </div><!-- /.project-card-one -->
                </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
            </div><!-- /.row gutter-y-30 -->
        </div><!-- /.container -->
    </section><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/partners/partners.blade.php ENDPATH**/ ?>