<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>


    <div class="slider-one">
        <div class="slider-one__carousel owl-carousel owl-theme thm-owl__carousel"
             data-owl-options='{"loop": true,
             "items": 1,
             "navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
             "margin": 0,
             "dots": true,
             "nav": true,
             "animateOut":
             "slideOutDown",
             "animateIn": "fadeIn",
             "active": true,
             "smartSpeed": 1000,
             "autoplay": true,
             "autoplayTimeout": 7000,
             "autoplayHoverPause": false}'>
            <div class="item slider-one__slide-1">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/1.png')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>
                        <!-- /.slider-one__floated -->
                        <p class="slider-one__text">Welcome to Right Time Limited</p><!-- /.slider-one__text -->
                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">Information Security Services <br>
                                and Solutions</h2><!-- /.slider-one__title -->
                        </div><!-- /.slider-one__title-wrapper -->
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
            <div class="item slider-one__slide-2">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s2.png')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>
                        <!-- /.slider-one__floated -->
                        <p class="slider-one__text">We, Right Time Limited</p><!-- /.slider-one__text -->
                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">First Ever QSA Firm in <br>
                                Bangladesh</h2><!-- /.slider-one__title -->
                        </div><!-- /.slider-one__title-wrapper -->
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
               <div class="item slider-one__slide-3">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s3.png')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>

                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">Real Hackers !!! <br></h2>
                        </div>
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
               <div class="item slider-one__slide-4">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s4.jpeg')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>
                        <!-- /.slider-one__floated -->
                        <p class="slider-one__text">We, Right Time Limited</p><!-- /.slider-one__text -->
                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">First Ever QSA Firm in <br>
                                Bangladesh</h2><!-- /.slider-one__title -->
                        </div><!-- /.slider-one__title-wrapper -->
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
               <div class="item slider-one__slide-5">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/2.png')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>
                        <!-- /.slider-one__floated -->
                        <p class="slider-one__text">We, Right Time Limited</p><!-- /.slider-one__text -->
                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">First Ever QSA Firm in <br>
                                Bangladesh</h2><!-- /.slider-one__title -->
                        </div><!-- /.slider-one__title-wrapper -->
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
               <div class="item slider-one__slide-6">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s5.png')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>
                        <!-- /.slider-one__floated -->
                        <p class="slider-one__text">We, Right Time Limited</p><!-- /.slider-one__text -->
                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">First Ever QSA Firm in <br>
                                Bangladesh</h2><!-- /.slider-one__title -->
                        </div><!-- /.slider-one__title-wrapper -->
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
               <div class="item slider-one__slide-7">
                <div class="slider-one__bg" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s6.png')); ?>);">
                </div><!-- /.slider-one__bg -->
                <div class="slider-one__line"></div><!-- /.slider-one__line -->
                <div class="slider-one__shape-1"></div><!-- /.slider-one__shape-1 -->
                <div class="slider-one__shape-2"></div><!-- /.slider-one__shape-2 -->
                <div class="slider-one__shape-3"></div><!-- /.slider-one__shape-3 -->
                <div class="container">
                    <div class="slider-one__content ">
                        <div class="slider-one__floated lettering-text">technology</div>
                        <!-- /.slider-one__floated -->
                        <p class="slider-one__text">We, Right Time Limited</p><!-- /.slider-one__text -->
                        <div class="slider-one__title-wrapper">
                            <h2 class="slider-one__title">First Ever QSA Firm in <br>
                                Bangladesh</h2><!-- /.slider-one__title -->
                        </div><!-- /.slider-one__title-wrapper -->
                        <div class="slider-one__btns">
                            <a href="<?php echo e(url('/about-us')); ?>" class="thm-btn slider-one__btn"><span>Details</span></a>
                            <!-- /.thm-btn slider-one__btn -->
                        </div><!-- /.slider-one__btns -->
                    </div><!-- /.slider-one__content -->
                </div><!-- /.container -->
            </div><!-- /.item -->
        </div><!-- /.slider-one__carousel -->
    </div><!-- /.slider-one -->

    <section class="section-padding--bottom section-padding--top about-five">
        <div class="container">
            <div class="row gutter-y-60">
                <div class="col-lg-6">
                    <div class="about-five__images">
                        <div class="about-five__images__shape"></div><!-- /.about-five__images__shape -->
                        <img src="<?php echo e(asset('frontend/assets/images/resources/about_rt.png')); ?>" class="wow fadeInUp"
                             data-wow-duration="1500ms" alt="">
                        <!--<img src="<?php echo e(asset('frontend/assets/images/resources/about-five-1-2.jpg')); ?>" alt="">-->
                        <!--<div class="about-five__video">-->
                        <!--    <a href="https://www.youtube.com/watch?v=rzfmZC3kg3M" class="video-popup">-->
                        <!--        <i class="fa fa-play"></i>-->
                        <!--    </a>-->
                        <!--</div><!-- /.about-five__video -->
                        <div class="about-five__images__caption count-box wow fadeInUp" data-wow-duration="1500ms">
                            <span class="count-text" data-stop="13" data-speed="1300">00</span>
                            Years of<br>
                            Experience
                        </div><!-- /.about-five__images__caption -->
                    </div><!-- /.about-five__images -->
                </div><!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="about-five__content">
                        <div class="section-title ">
                            <p class="section-title__text">About Company</p><!-- /.section-title__text -->
                            <h2 class="section-title__title">Leading Information Security Company</h2>
                            <!-- /.section-title__title -->
                        </div><!-- /.section-title -->
                        <div class="about-five__text">Right Time Limited (“RightTime”, short form) started its journey in the year 2009.
                            It’s purely an Information Security Consultation, Assessment/Audit Service & Solutions Provider.
                            With all related International Standards and Association, we are providing Information System Audit,
                            Technical Documentation, Project Management, Custom Skill Development, ISO Consultation & Certification,
                            SWIFT Consultation & Auditing, PCI DSS Gap Assessment, Remediation Consultation, Auditing & Certification.
                            Conducting Security Assessment e.g. VA & PT, Forensic (with the use of multiple world class Automated & Manual tools).
                            As the first empaneled Security Assessor firm we are serving for more than 13 years.</div>
                        <!-- /.about-five__text -->


                        <!-- /.about-five__text -->



















                        <div class="about-four__meta">
                            <div class="about-four__author">
                                <img src="<?php echo e(asset('frontend/assets/images/team/ceo.jpg')); ?>" alt="">
                                <div class="about-four__author__content">
                                    <h3 class="about-four__author__title">Mohammad Tohidur Rahman Bhuiyan, PhD</h3>
                                    <!-- /.about-four__author__title -->
                                    <div class="about-four__author__designation">MD & CEO</div>
                                    <!-- /.about-four__author__designation -->
                                </div><!-- /.about-four__author__content -->
                            </div><!-- /.about-four__author -->
                            <a href="https://www.linkedin.com/in/mohammad-tohidur-rahman-bhuiyan-a8805a6/" class="thm-btn about-four__btn"><span>Learn More</span></a>
                            <!-- /.thm-btn about-four__btn -->
                        </div><!-- /.about-four__meta -->
                    </div><!-- /.about-five__content -->
                </div><!-- /.col-lg-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

<section
    class="section-padding--top service-four gray-bg section-padding-lg--bottom section-has-bottom-margin background-repeat-no background-position-top-right"
    style="background-image: url(<?php echo e(asset('frontend/assets/images/shapes/service-four-bg-1-1.png')); ?>);">
    <div class="container">
        <div class="section-title text-center">
            <p class="section-title__text">Popular Services</p><!-- /.section-title__text -->
            <h2 class="section-title__title">We Provide Our Client Best <br>Information Security Solution & Services</h2>
            <!-- /.section-title__title -->
        </div><!-- /.section-title -->
        <div class="owl-carousel thm-owl__carousel thm-owl__carousel--with-shadow service-four__carousel"
             data-owl-options='{"loop": true,
				"autoplay": true,
				"autoplayTimeout": 1500,
				"nav": false,
				"navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
				"dots": false,
				"margin": 0,
                "items": 1,
				"smartSpeed": 700,
				"responsive": {
					"0": {
						"margin": 0,
						"items": 1
					},
					"576": {
						"margin": 30,
						"items": 2
					},
					"768": {
						"margin": 30,
						"items": 3
					},
					"992": {
						"margin": 30,
						"items": 4
					},
					"1200": {
						"margin": 30,
						"items": 6
					}
				}}'>
            <div class="item">
                <div class="service-card-three">
                    <div class="service-card-three__icon">
                        <i class="icon-new-product"></i>
                    </div><!-- /.service-card-three__icon -->
                    <div class="service-card-three__content">
                        <h3 class="service-card-three__title"><a href="<?php echo e(url('/services/consultation')); ?>">Consultation
                                <br></a></h3><!-- /.service-card-three__title -->
                        <div class="service-card-three__text">Providing the solutions for non-IT businesses.
                        </div><!-- /.service-card-three__text -->
                    </div><!-- /.service-card-three__content -->
                </div><!-- /.service-card-three -->
            </div><!-- /.item -->
            <div class="item">
                <div class="service-card-three">
                    <div class="service-card-three__icon">
                        <i class="icon-new-product"></i>
                    </div><!-- /.service-card-three__icon -->
                    <div class="service-card-three__content">
                        <h3 class="service-card-three__title"><a href="<?php echo e(url('/services/auditing')); ?>">Auditing</a></h3><!-- /.service-card-three__title -->
                        <div class="service-card-three__text">Providing the solutions for non-IT businesses.
                        </div><!-- /.service-card-three__text -->
                    </div><!-- /.service-card-three__content -->
                </div><!-- /.service-card-three -->
            </div><!-- /.item -->
            <div class="item">
                <div class="service-card-three">
                    <div class="service-card-three__icon">
                        <i class="icon-protection"></i>
                    </div><!-- /.service-card-three__icon -->
                    <div class="service-card-three__content">
                        <h3 class="service-card-three__title"><a
                                href="<?php echo e(url('/services/security-assessment-testing')); ?>">Security <br>
                                Assessment & Testing</a></h3><!-- /.service-card-three__title -->
                        <div class="service-card-three__text">Providing the solutions for non-IT businesses.
                        </div><!-- /.service-card-three__text -->
                    </div><!-- /.service-card-three__content -->
                </div><!-- /.service-card-three -->
            </div><!-- /.item -->
            <div class="item">
                <div class="service-card-three">
                    <div class="service-card-three__icon">
                        <i class="icon-web-development"></i>
                    </div><!-- /.service-card-three__icon -->
                    <div class="service-card-three__content">
                        <h3 class="service-card-three__title"><a href="<?php echo e(url('/services/standard-implementation-certification')); ?>">Standard
                                <br>
                                Implementation & Certification</a></h3><!-- /.service-card-three__title -->
                        <div class="service-card-three__text">Providing the solutions for non-IT businesses.
                        </div><!-- /.service-card-three__text -->
                    </div><!-- /.service-card-three__content -->
                </div><!-- /.service-card-three -->
            </div><!-- /.item -->


            <div class="item">
                <div class="service-card-three">
                    <div class="service-card-three__icon">
                        <i class="icon-analysis"></i>
                    </div><!-- /.service-card-three__icon -->
                    <div class="service-card-three__content">
                        <h3 class="service-card-three__title"><a href="<?php echo e(url('/services/solutions')); ?>">Solutions</a></h3><!-- /.service-card-three__title -->
                        <div class="service-card-three__text">Providing the solutions for non-IT businesses.
                        </div><!-- /.service-card-three__text -->
                    </div><!-- /.service-card-three__content -->
                </div><!-- /.service-card-three -->
            </div><!-- /.item -->


        </div><!-- /.owl-carousel -->
    </div><!-- /.container -->
</section>

    <section class="funfact-one">
        <div class="container">
            <div class="funfact-one__inner wow fadeInUp background-size-cover" data-wow-duration="1500ms"
                 style="background-image: url(<?php echo e(asset('frontend/assets/images/shapes/funfact-one-bg.png')); ?>);">
                <ul class="funfact-one__list">
                    <li class="funfact-one__list__item">
                        <h3 class="funfact-one__list__title count-box">
                            <span data-stop="255" data-speed="2500" class="count-text">00</span>
                        </h3><!-- /.funfact-one__list__title -->
                        <p class="funfact-one__list__text">Business Interogation</p>
                        <!-- /.funfact-one__list__text -->
                    </li>
                    <li class="funfact-one__list__item">
                        <h3 class="funfact-one__list__title count-box">
                            <span data-stop="325" data-speed="2500" class="count-text">00</span>
                        </h3><!-- /.funfact-one__list__title -->
                        <p class="funfact-one__list__text">Strategies Planned</p>
                        <!-- /.funfact-one__list__text -->
                    </li>
                    <li class="funfact-one__list__item">
                        <h3 class="funfact-one__list__title count-box">
                            <span data-stop="569" data-speed="2500" class="count-text">00</span>
                        </h3><!-- /.funfact-one__list__title -->
                        <p class="funfact-one__list__text">Projects Relased</p>
                        <!-- /.funfact-one__list__text -->
                    </li>
                    <li class="funfact-one__list__item">
                        <h3 class="funfact-one__list__title count-box">
                            <span data-stop="769" data-speed="2500" class="count-text">00</span>
                        </h3><!-- /.funfact-one__list__title -->
                        <p class="funfact-one__list__text">Satisfied Clients </p>
                        <!-- /.funfact-one__list__text -->
                    </li>
                </ul><!-- /.funfact-one__list -->
            </div><!-- /.funfact-one__inner -->
        </div><!-- /.container -->
    </section>

<!--Our Association-->

<section class="section-padding--top section-padding--bottom about-one-associate">
    <div class="section-title text-center">

        <h2 class="section-title__title">OUR ASSOCIATIONS</h2>
        <!-- /.section-title__title -->
    </div><!-- /.section-title -->
    <div class="client-carousel client-carousel--two">
        <div class="container">
            <div class="owl-carousel thm-owl__carousel" data-owl-options='{"loop": true,
				"autoplay": true,
				"autoplayTimeout": 5000,
				"autoplayHoverPause": true,
				"nav": true,
				"navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
				"dots": false,
				"margin": 30,
                "items": 2,
				"smartSpeed": 700,
				"responsive": {
					"0": {
						"margin": 30,
						"items": 2
					},
					"375": {
						"margin": 30,
						"items": 2
					},
					"575": {
						"margin": 30,
						"items": 3
					},
					"767": {
						"margin": 50,
						"items": 4
					},
					"991": {
						"margin": 40,
						"items": 5
					},
					"1199": {
						"margin": 80,
						"items": 5
					}
				}}'>
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/pci.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/basis.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/ecab.jpg')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/bcs.jpg')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/bf.jpg')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/wbg.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/association/cca.png')); ?>" alt="">
                </div><!-- /.item -->

            </div><!-- /.thm-owl__carousel -->
        </div><!-- /.container -->
    </div><!-- /.client-carousel -->

</section>

<section class="section-padding--top section-padding--bottom about-one">
    <div class="section-title text-center">

        <h2 class="section-title__title">OUR PARTNERS</h2>
        <!-- /.section-title__title -->
    </div><!-- /.section-title -->
    <div class="client-carousel client-carousel--two">
        <div class="container">
            <div class="owl-carousel thm-owl__carousel" data-owl-options='{"loop": true,
				"autoplay": true,
				"autoplayTimeout": 5000,
				"autoplayHoverPause": true,
				"nav": true,
				"navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
				"dots": false,
				"margin": 30,
                "items": 2,
				"smartSpeed": 700,
				"responsive": {
					"0": {
						"margin": 30,
						"items": 2
					},
					"375": {
						"margin": 30,
						"items": 2
					},
					"575": {
						"margin": 30,
						"items": 3
					},
					"767": {
						"margin": 50,
						"items": 4
					},
					"991": {
						"margin": 40,
						"items": 5
					},
					"1199": {
						"margin": 80,
						"items": 5
					}
				}}'>
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/partners/ec.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/partners/pv.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/partners/acnabin.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/partners/pecb-logo.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/partners/sck.png')); ?>" alt="">
                </div><!-- /.item -->
                <div class="item">
                    <img src="<?php echo e(asset('frontend/assets/images/partners/ars.png')); ?>" alt="">
                </div><!-- /.item -->

            </div><!-- /.thm-owl__carousel -->
        </div><!-- /.container -->
    </div><!-- /.client-carousel -->

</section>


<section
    class="section-padding service-four gray-bg section-padding-l--bottom h-25 section-has-bottom-margin background-repeat-no background-position-top-right"
    style="background-image: url(<?php echo e(asset('frontend/assets/images/shapes/service-four-bg-1-1.png')); ?>);"><br>
    <div class="container">
        <div class="section-title text-center">

            <h2 class="section-title__title">We Provide Our Client Best <br>Information Security Services</h2>
            <!-- /.section-title__title -->
        </div><!-- /.section-title -->
        <div class="client-carousel client-carousel--two">
            <div class="container">
                <div class="owl-carousel thm-owl__carousel" data-owl-options='{"loop": true,
				"autoplay": true,
				"autoplayTimeout": 1500,
				"autoplayHoverPause": true,
				"nav": true,
				"navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
				"dots": false,
				"margin": 30,
                "items": 2,
				"smartSpeed": 700,
				"responsive": {
					"0": {
						"margin": 30,
						"items": 2
					},
					"375": {
						"margin": 30,
						"items": 2
					},
					"575": {
						"margin": 30,
						"items": 3
					},
					"767": {
						"margin": 50,
						"items": 4
					},
					"991": {
						"margin": 40,
						"items": 5
					},
					"1200": {
						"margin": 5,
						"items": 5
					}
				}}'>
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/clients/bb1.jpg')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/clients/nrbc logo.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/clients/surjo.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/clients/aibl.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/clients/ssf.png')); ?>" size=small alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/agrani bank.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/rupali bank.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/nrb-bank.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/IFIC-Logo.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/SMBL-Logo.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/IFC-Logo.svg')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/Transparency International Bangladesh.png')); ?>"  alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/paywell.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/Shahajalal Islami Bank_Logo.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/mutual-trust.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/meghnagbanklogo.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/walletmix.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/circle-fintech.png')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/addiesoftlogo.svg')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/cca.jpg')); ?>" alt="">
                    </div><!-- /.item -->
                    <div class="item">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/genweb2.webp')); ?>" alt="">
                    </div><!-- /.item -->
                </div><!-- /.thm-owl__carousel -->
            </div><!-- /.container -->
        </div><!-- /.client-carousel -->
    </div><!-- /.container -->
</section><br><br><br>


<!--Project Was Here-->

    <section class="black-bg section-padding-lg--top section-padding-lg--bottom cta-two">
        <div class="cta-two__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s4.jpeg')); ?>);"></div>
        <div class="container">
            <div class="cta-two__inner">
                <h3 class="cta-two__title">Better Information Security Services And Solutions
                    At Your <span>Fingertips</span></h3><!-- /.cta-two__title -->
                <a href="contact.html" class="thm-btn cta-two__btn"><span>LEarn More</span></a>
                <!-- /.thm-btn cta-two__btn -->
            </div><!-- /.cta-two__inner -->
        </div><!-- /.container -->
    </section>
    <section
        class="section-padding--bottom section-padding--top testimonials-two background-repeat-no background-position-top-center"
        style="background-image: url(<?php echo e(asset('frontend/assets/images/background/testi-bg-1-1.png')); ?>);">
        <div class="container">
            <div class="row gutter-y-60">
                <div class="col-lg-5">
                    <div class="testimonials-two__content">
                        <div class="section-title ">
                            <p class="section-title__text">Our clients</p><!-- /.section-title__text -->
                            <h2 class="section-title__title">We Are Trusted
                                Worldwide Peoples</h2><!-- /.section-title__title -->
                        </div><!-- /.section-title -->
                        <div class="testimonials-two__content__text">Sed ut perspiciatis unde omnis natus error sit
                            voluptatem accusa ntium doloremque laudantium totam rem aperiamea queipsa quae abillo
                            inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</div>
                        <!-- /.testimonials-two__content__text -->
                        <div class="testimonials-two__content__text">Pellentesque gravida lectus vitae nisi luctus,
                            Finibus aliquet ligula ultrices.</div><!-- /.testimonials-two__content__text -->
                        <a href="about.html" class="thm-btn testimonials-two__content__btn"><span>View All
									feedbacks</span></a><!-- /.thm-btn testimonials-two__content__btn -->
                    </div><!-- /.testimonials-two__content -->
                </div><!-- /.col-lg-5 -->
                <div class="col-lg-7">
                    <div class="testimonials-two__items">
                        <div class="row gutter-y-30">
                            <div class="col-lg-12">
                                <div class="testimonials-one-card">
                                    <div class="testimonials-one-card__image">
                                        <img src="<?php echo e(asset('frontend/assets/images/resources/testi-1-1.jpg')); ?>" alt="">
                                    </div><!-- /.testimonials-one-card__image -->
                                    <div class="testimonials-one-card__content">
                                        <div class="testimonials-one-card__text">On the other hand denounc with
                                            ghteo
                                            indignation and dislike men who so beguiled and demoralized the charms
                                            of
                                            pleasure
                                            the momen blinded by desire cannot foresee the pain and trouble.</div>
                                        <!-- /.testimonials-one-card__text -->
                                        <h3 class="testimonials-one-card__title">Michal Rahul</h3>
                                        <!-- /.testimonials-one-card__title -->
                                        <p class="testimonials-one-card__designation">Ul - UX Designer</p>
                                        <!-- /.testimonials-one-card__designation -->
                                        <i class="icon-right-quote testimonials-one-card__icon"></i>
                                    </div><!-- /.testimonials-one-card__content -->
                                </div><!-- /.testimonials-one-card -->
                            </div><!-- /.col-lg-6 -->
                            <div class="col-lg-12">
                                <div class="testimonials-one-card">
                                    <div class="testimonials-one-card__image">
                                        <img src="<?php echo e(asset('frontend/assets/images/resources/testi-1-2.jpg')); ?>" alt="">
                                    </div><!-- /.testimonials-one-card__image -->
                                    <div class="testimonials-one-card__content">
                                        <div class="testimonials-one-card__text">On the other hand denounc with
                                            ghteo
                                            indignation and dislike men who so beguiled and demoralized the charms
                                            of
                                            pleasure
                                            the momen blinded by desire cannot foresee the pain and trouble.</div>
                                        <!-- /.testimonials-one-card__text -->
                                        <h3 class="testimonials-one-card__title">Jessica Brown</h3>
                                        <!-- /.testimonials-one-card__title -->
                                        <p class="testimonials-one-card__designation">Ul - UX Designer</p>
                                        <!-- /.testimonials-one-card__designation -->
                                        <i class="icon-right-quote testimonials-one-card__icon"></i>
                                    </div><!-- /.testimonials-one-card__content -->
                                </div><!-- /.testimonials-one-card -->
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                    </div><!-- /.testimonials-two__items -->
                </div><!-- /.col-lg-7 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>


<!--Team Was Here -->

    <section class=" section-padding--top about-three about-three--home-one">
        <div class="about-three__shape wow fadeInRight" data-wow-duration="1500ms"
             <!--style="background-image: url(<?php echo e(asset('frontend/assets/images/shapes/about-three-s-1.png')); ?>);"> -->
        </div><!-- /.about-three__shape -->
        <div class="container">
            <div class="row gutter-y-60">
                <div class="col-lg-6">
                    <div class="about-three__image">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/rt1.png')); ?>" class="wow fadeInUp"
                             data-wow-duration="1500ms" alt="">
                    </div><!-- /.about-three__image -->
                </div><!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="about-three__content">
                        <div class="section-title ">
                            <p class="section-title__text">Company Benefits</p><!-- /.section-title__text -->
                            <h2 class="section-title__title">Why You Should Choose
                                Our Services</h2><!-- /.section-title__title -->
                        </div><!-- /.section-title -->
                        <div class="about-three__text">Choose Infetech to have custom software solutions for your
                            business with the most reasonable price.</div><!-- /.about-three__text -->
                        <ul class="about-three__list">
                            <li class="about-three__list__item">
                                <div class="about-three__list__icon">
                                    <i class="icon-cloud"></i>
                                </div><!-- /.about-three__list__icon -->
                                <div class="about-three__list__content">
                                    <h3 class="about-three__list__title"><a href="service-cyber-security.html">Cloud
                                            Based Services</a></h3><!-- /.about-three__list__title -->
                                    <p class="about-three__list__text">Services address a range of simply free text
                                        application and infrastructure needs.</p><!-- /.about-three__list__text -->
                                </div><!-- /.about-three__list__content -->
                            </li>
                            <li class="about-three__list__item">
                                <div class="about-three__list__icon">
                                    <i class="icon-group"></i>
                                </div><!-- /.about-three__list__icon -->
                                <div class="about-three__list__content">
                                    <h3 class="about-three__list__title"><a href="team.html">Expert Team Members</a>
                                    </h3><!-- /.about-three__list__title -->
                                    <p class="about-three__list__text">Services address a range of simply free text
                                        application and infrastructure needs.</p>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <!-- /.about-three__list__text -->
                                </div><!-- /.about-three__list__content -->
                            </li>
                        </ul><!-- /.about-three__list -->
                    </div><!-- /.about-three__content -->
                </div><!-- /.col-lg-6 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

<!--Blog Section Was Here-->


    <section class="cta-one">
        <div class="container">
            <div class="cta-one__inner text-center wow fadeInUp" data-wow-duration="1500ms">
                <div class="cta-one__circle"></div><!-- /.cta-one__circle -->
                <div class="section-title ">
                    <p class="section-title__text">Need Any Technology Solution</p><!-- /.section-title__text -->
                    <h2 class="section-title__title section-title__title--light">Let’s Work Togather on Project</h2>
                    <!-- /.section-title__title -->
                </div><!-- /.section-title -->
                <a href="contact.html" class="thm-btn thm-btn--light cta-one__btn"><span>Start Now</span></a>
                <!-- /.thm-btn thm-btn--light cta-one__btn -->
            </div><!-- /.cta-one__inner -->
        </div><!-- /.container -->
    </section><!-- /.cta-one -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/index.blade.php ENDPATH**/ ?>