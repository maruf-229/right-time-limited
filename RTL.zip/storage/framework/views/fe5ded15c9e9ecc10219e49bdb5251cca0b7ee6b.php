<h3 class="sidebar__title">Industries</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('aus/industries/bank-nbfi')); ?>">Bank & NBFI</a></li>
    <li><a href="<?php echo e(url('aus/industries/telecommunications')); ?>">Telecommunications</a></li>
    <li><a href="<?php echo e(url('aus/industries/pci')); ?>">Payment Card Industry</a></li>
    <li><a href="<?php echo e(url('aus/industries/educational-institutions')); ?>">Educational Institutions</a></li>
    <li><a href="<?php echo e(url('aus/industries/erm')); ?>">eCommerce & Retail Merchants</a></li>
    <li><a href="<?php echo e(url('aus/industries/health-care')); ?>">Health Care</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/aus/industries/common.blade.php ENDPATH**/ ?>