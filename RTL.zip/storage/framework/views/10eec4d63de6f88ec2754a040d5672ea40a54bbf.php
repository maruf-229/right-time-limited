<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title'); ?>
        About-Us
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/resources/aboutbg1.png')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="index.html">Home</a></li>
                <li>About</li>
            </ul>
            <h2 class="page-header__title">About Us</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->
    <section class="about-four section-padding--top">
        <div class="container">
            <div class="row gutter-y-60">
                <div class="col-lg-6">
                    <div class="about-four__image">
                        <img src="<?php echo e(asset('frontend/assets/images/resources/rt1.png')); ?>" class="wow fadeInUp"
                             data-wow-duration="1500ms" alt="">
                    </div><!-- /.about-four__image -->
                </div><!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="about-four__content">
                        <div class="section-title ">
                            <p class="section-title__text">About Company</p><!-- /.section-title__text -->
                            <h2 class="section-title__title">Leading Information Security Company</h2><!-- /.section-title__title -->
                        </div><!-- /.section-title -->
                        <div class="about-four__text">Right Time Limited (“RightTime”, short form) started its journey in the year 2009. 
                        It’s purely an Information Security Consultation, Assessment/Audit Service & Solutions Provider. With all related International 
                        Standards and Association, we are providing Information System Audit, Technical Documentation, Project Management, Custom Skill Development, ISO Consultation & Certification, SWIFT Consultation & Auditing, PCI DSS Gap Assessment, Remediation Consultation, Auditing & Certification. Conducting Security Assessment 
                        e.g. VA & PT, Forensic (with the use of multiple world class Automated & Manual tools). 
                        As the first empaneled Security Assessor firm we are serving for more than 13 years..</div>
                        <!-- /.about-four__text -->
                        
                    </div><!-- /.about-four__content -->
                </div><!-- /.col-lg-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
    <section class="section-padding--bottom section-padding--top">
        <div class="container">
            <div class="section-title text-center">
                <p class="section-title__text">Our Team members</p><!-- /.section-title__text -->
                <h2 class="section-title__title">Our Expert Person to Provide <br> IT Solution Services</h2>
                <!-- /.section-title__title -->
            </div><!-- /.section-title -->
            <div class="row gutter-y-30">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="team-card-one wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="000ms">
                        <div class="team-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/team/c.jpg')); ?>" alt="">
                            <div class="team-card-one__social">
                                <ul class="team-card-one__social__links">
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                </ul><!-- /.team-card-one__social__links -->
                                <div class="team-card-one__social__icon">
                                    <i class="fa fa-share-alt"></i>
                                </div><!-- /.team-card-one__social__icon -->
                            </div><!-- /.team-card-one__social -->
                        </div><!-- /.team-card-one__image -->
                        <div class="team-card-one__content">
                            <h3 class="team-card-one__title"><a href="#">Sahaly Yasmin Bhuiyan</a></h3>
                            <!-- /.team-card-one__title -->
                            <p class="team-card-one__designation">Chairman</p><!-- /.team-card-one__designation -->
                        </div><!-- /.team-card-one__content -->
                    </div><!-- /.team-card-one -->
                </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="team-card-one wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="100ms">
                        <div class="team-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/team/ceo1.jpg')); ?>" alt="">
                            <div class="team-card-one__social">
                                <ul class="team-card-one__social__links">
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                </ul><!-- /.team-card-one__social__links -->
                                <div class="team-card-one__social__icon">
                                    <i class="fa fa-share-alt"></i>
                                </div><!-- /.team-card-one__social__icon -->
                            </div><!-- /.team-card-one__social -->
                        </div><!-- /.team-card-one__image -->
                        <div class="team-card-one__content">
                            <h3 class="team-card-one__title"><a href="#">Mohammad Tohidur Rahman Bhuiyan</a></h3>
                            <!-- /.team-card-one__title -->
                            <p class="team-card-one__designation">MD & CEO and Lead Assessor</p><!-- /.team-card-one__designation -->
                        </div><!-- /.team-card-one__content -->
                    </div><!-- /.team-card-one -->
                </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="team-card-one wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
                        <div class="team-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/team/ars.jpg')); ?>" alt="">
                            <div class="team-card-one__social">
                                <ul class="team-card-one__social__links">
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                </ul><!-- /.team-card-one__social__links -->
                                <div class="team-card-one__social__icon">
                                    <i class="fa fa-share-alt"></i>
                                </div><!-- /.team-card-one__social__icon -->
                            </div><!-- /.team-card-one__social -->
                        </div><!-- /.team-card-one__image -->
                        <div class="team-card-one__content">
                            <h3 class="team-card-one__title"><a href="#">Arshad Mahmud</a></h3>
                            <!-- /.team-card-one__title -->
                            <p class="team-card-one__designation">Chief Operating Officer</p><!-- /.team-card-one__designation -->
                        </div><!-- /.team-card-one__content -->
                    </div><!-- /.team-card-one -->
                </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
                
                
                                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="team-card-one wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
                        <div class="team-card-one__image">
                            <br>
                            <img src="<?php echo e(asset('frontend/assets/images/team/rashed.jpg')); ?>" alt="">
                            <div class="team-card-one__social">
                                <ul class="team-card-one__social__links">
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                </ul><!-- /.team-card-one__social__links -->
                                <div class="team-card-one__social__icon">
                                    <i class="fa fa-share-alt"></i>
                                </div><!-- /.team-card-one__social__icon -->
                            </div><!-- /.team-card-one__social -->
                        </div><!-- /.team-card-one__image -->
                        <div class="team-card-one__content">
                            <h3 class="team-card-one__title"><a href="#">Rashed Sarwar</a></h3>
                            <!-- /.team-card-one__title -->
                            <p class="team-card-one__designation">Country Head, USA</p><!-- /.team-card-one__designation -->
                        </div><!-- /.team-card-one__content -->
                    </div><!-- /.team-card-one -->
                </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
                
                                                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="team-card-one wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
                        <div class="team-card-one__image">
                            <br>
                            <img src="<?php echo e(asset('frontend/assets/images/team/idk.jpg')); ?>" alt="">
                            <div class="team-card-one__social">
                                <ul class="team-card-one__social__links">
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                </ul><!-- /.team-card-one__social__links -->
                                <div class="team-card-one__social__icon">
                                    <i class="fa fa-share-alt"></i>
                                </div><!-- /.team-card-one__social__icon -->
                            </div><!-- /.team-card-one__social -->
                        </div><!-- /.team-card-one__image -->
                        <div class="team-card-one__content">
                            <h3 class="team-card-one__title"><a href="#">Ms. Melinda</a></h3>
                            <!-- /.team-card-one__title -->
                            <p class="team-card-one__designation">Country Head, Germany</p><!-- /.team-card-one__designation -->
                        </div><!-- /.team-card-one__content -->
                    </div><!-- /.team-card-one -->
                </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
                
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="team-card-one wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
                         <br>
                            <br>
                        <div class="team-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/team/mahfuj.png')); ?>" alt="">
                            <div class="team-card-one__social">
                                <ul class="team-card-one__social__links">
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                </ul><!-- /.team-card-one__social__links -->
                                <div class="team-card-one__social__icon">
                                    <i class="fa fa-share-alt"></i>
                                </div><!-- /.team-card-one__social__icon -->
                            </div><!-- /.team-card-one__social -->
                        </div><!-- /.team-card-one__image -->
                        <div class="team-card-one__content">
                           
                            <h3 class="team-card-one__title"><a href="#">Dr. Mahfuz Ashraf</a></h3>
                            <!-- /.team-card-one__title -->
                            <p class="team-card-one__designation">Country Head, Australia</p><!-- /.team-card-one__designation -->
                        </div><!-- /.team-card-one__content -->
                    </div><!-- /.team-card-one -->
                </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
    <section class="black-bg section-padding-lg--top section-padding-lg--bottom cta-two">
        <div class="cta-two__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/s4.jpeg')); ?>);"></div>
        <div class="container">
            <div class="cta-two__inner">
                <h3 class="cta-two__title">Better Information Security Services And Solutions
                    At Your <span>Fingertips</span></h3><!-- /.cta-two__title -->
                <a href="contact.html" class="thm-btn cta-two__btn"><span>LEarn More</span></a>
                <!-- /.thm-btn cta-two__btn -->
            </div><!-- /.cta-two__inner -->
        </div><!-- /.container -->
    </section>
    <section
        class="section-padding--bottom section-padding--top testimonials-two background-repeat-no background-position-top-center"
        style="background-image: url(<?php echo e(asset('frontend/assets/images/shapes/testi-bg-1-1.png')); ?>);">
        <div class="container">
            <div class="row gutter-y-60">
                <div class="col-lg-5">
                    <div class="testimonials-two__content">
                        <div class="section-title ">
                            <p class="section-title__text">Our clients</p><!-- /.section-title__text -->
                            <h2 class="section-title__title">We Are Trusted
                                Worldwide Peoples</h2><!-- /.section-title__title -->
                        </div><!-- /.section-title -->
                        <div class="testimonials-two__content__text">Sed ut perspiciatis unde omnis natus error sit
                            voluptatem accusa ntium doloremque laudantium totam rem aperiamea queipsa quae abillo
                            inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</div>
                        <!-- /.testimonials-two__content__text -->
                        <div class="testimonials-two__content__text">Pellentesque gravida lectus vitae nisi luctus,
                            Finibus aliquet ligula ultrices.</div><!-- /.testimonials-two__content__text -->
                        <a href="about.html" class="thm-btn testimonials-two__content__btn"><span>View All
									feedbacks</span></a><!-- /.thm-btn testimonials-two__content__btn -->
                    </div><!-- /.testimonials-two__content -->
                </div><!-- /.col-lg-5 -->
                <div class="col-lg-7">
                    <div class="testimonials-two__items">
                        <div class="row gutter-y-30">
                            <div class="col-lg-12">
                                <div class="testimonials-one-card">
                                    <div class="testimonials-one-card__image">
                                        <img src="<?php echo e(asset('frontend/assets/images/resources/testi-1-1.jpg')); ?>" alt="">
                                    </div><!-- /.testimonials-one-card__image -->
                                    <div class="testimonials-one-card__content">
                                        <div class="testimonials-one-card__text">On the other hand denounc with
                                            ghteo
                                            indignation and dislike men who so beguiled and demoralized the charms
                                            of
                                            pleasure
                                            the momen blinded by desire cannot foresee the pain and trouble.</div>
                                        <!-- /.testimonials-one-card__text -->
                                        <h3 class="testimonials-one-card__title">Michal Rahul</h3>
                                        <!-- /.testimonials-one-card__title -->
                                        <p class="testimonials-one-card__designation">Ul - UX Designer</p>
                                        <!-- /.testimonials-one-card__designation -->
                                        <i class="icon-right-quote testimonials-one-card__icon"></i>
                                    </div><!-- /.testimonials-one-card__content -->
                                </div><!-- /.testimonials-one-card -->
                            </div><!-- /.col-lg-6 -->
                            <div class="col-lg-12">
                                <div class="testimonials-one-card">
                                    <div class="testimonials-one-card__image">
                                        <img src="<?php echo e(asset('frontend/assets/images/resources/testi-1-2.jpg')); ?>" alt="">
                                    </div><!-- /.testimonials-one-card__image -->
                                    <div class="testimonials-one-card__content">
                                        <div class="testimonials-one-card__text">On the other hand denounc with
                                            ghteo
                                            indignation and dislike men who so beguiled and demoralized the charms
                                            of
                                            pleasure
                                            the momen blinded by desire cannot foresee the pain and trouble.</div>
                                        <!-- /.testimonials-one-card__text -->
                                        <h3 class="testimonials-one-card__title">Jessica Brown</h3>
                                        <!-- /.testimonials-one-card__title -->
                                        <p class="testimonials-one-card__designation">Ul - UX Designer</p>
                                        <!-- /.testimonials-one-card__designation -->
                                        <i class="icon-right-quote testimonials-one-card__icon"></i>
                                    </div><!-- /.testimonials-one-card__content -->
                                </div><!-- /.testimonials-one-card -->
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                    </div><!-- /.testimonials-two__items -->
                </div><!-- /.col-lg-7 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/securitypedia/righttime/resources/views/frontend/pages/about.blade.php ENDPATH**/ ?>