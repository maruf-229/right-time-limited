<h3 class="sidebar__title">Services</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('/services/consultation')); ?>">Consultation</a></li>
    <li><a href="<?php echo e(url('/services/auditing')); ?>">Auditing</a></li>
    <li><a href="<?php echo e(url('/services/security-assessment-testing')); ?>">Security Assessment & Testing</a></li>
    <li><a href="<?php echo e(url('/services/standard-implementation-certification')); ?>">Standard Implementation & Certification</a></li>
    <li><a href="<?php echo e(url('/services/security-training')); ?>">Security Training</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-partners\resources\views/frontend/services/common.blade.php ENDPATH**/ ?>
