<h3 class="sidebar__title">Security Assessment & Testing</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('de/services/security-assessment-testing/VAPT')); ?>">Vulnerability Assessment & Presentation Testing Services</a></li>
    <li><a href="<?php echo e(url('de/services/security-assessment-testing/digital-forensics')); ?>">Digital Forensics</a></li>
    <li><a href="<?php echo e(url('de/services/security-assessment-testing/code-review')); ?>">Code Review</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/de/services/sat/common.blade.php ENDPATH**/ ?>