<h3 class="sidebar__title">Management</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('/services/security-training/management/CDRP')); ?>">Certified Disaster Recovery Professional</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/CIH')); ?>">Certified Incident Handler</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/CSA')); ?>">Certified SOC Analyst(CSA)</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/CTIA')); ?>">Certified Threat Intelligence Analyst(CTIA)</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/CISA')); ?>">Certified Information Systems Auditor(CISA)</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/CISM')); ?>">Certified Information Security Manager(CISM)</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/CISSP')); ?>">Certified Information Systems Security Professional(CISSP)</a></li>
    <li><a href="<?php echo e(url('/services/security-training/management/GCPM')); ?>">GIAC Certified Project Manager (GCPM)</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/bd/services/st/management/cmn.blade.php ENDPATH**/ ?>