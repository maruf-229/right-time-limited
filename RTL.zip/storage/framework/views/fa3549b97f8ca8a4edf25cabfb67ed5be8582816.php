<h3 class="sidebar__title">Common</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('/services/security-training/common/assessment')); ?>">Assessment</a>
        <ul>
            <li><a href="<?php echo e(url('/services/security-training/common/information-technology')); ?>">Training on Information Technology Enabled Service</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/cyber-security')); ?>">Cyber Security</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/penetration-testing')); ?>">Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/CHFI')); ?>">Computer Hacking Forensic Investigator(CHFI)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/CTIA')); ?>">Certified Threat Intelligence Analyst(CTIA)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/CSA')); ?>">Certified SOC Analyst(CSA)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/OSINT')); ?>">Open Source Intelligence(OSINT)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/ethical-hacker')); ?>">Certified Ethical Hacker(CEH)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/CPENT')); ?>">Certified Penetration Tester (CPENT)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/professional-training')); ?>">Custom Professional Training for Fresh Graduates</a></li>
        </ul>
    </li>
    <li><a href="<?php echo e(url('/services/security-training/common/management')); ?>">Management</a>
        <ul>
            <li><a href="<?php echo e(url('/services/security-training/common/ISACA')); ?>">ISACA-Curriculam-(CISA,CISM)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/common/CISSP')); ?>">CISSP</a></li>
        </ul>
    </li>
</ul><!-- /.sidebar__category -->
<?php /**PATH /home/securitypedia/righttime/resources/views/frontend/bd/services/st/common/cmn.blade.php ENDPATH**/ ?>