<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title'); ?>
        Careers
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('https://www.krg.ca/en-CA/assets/Careers-new.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>Careers</li>
            </ul>
            <h2 class="page-header__title">Careers</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->
<br><br><br>
<p>
No jobs available right now.
</p>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.bd.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/securitypedia/righttime/resources/views/frontend/bd/blog/blog.blade.php ENDPATH**/ ?>