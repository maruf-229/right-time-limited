<h3 class="sidebar__title">Custom</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('/services/security-training/custom/assessment')); ?>">Assessment</a>
        <ul>
            <li><a href="<?php echo e(url('/services/security-training/custom/information-technology')); ?>">Training on Information Technology Enabled Service</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/cyber-security')); ?>">Cyber Security</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/penetration-testing')); ?>">Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/CHFI')); ?>">Computer Hacking Forensic Investigator(CHFI)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/CTIA')); ?>">Certified Threat Intelligence Analyst(CTIA)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/CSA')); ?>">Certified SOC Analyst(CSA)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/OSINT')); ?>">Open Source Intelligence(OSINT)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/ethical-hacker')); ?>">Certified Ethical Hacker(CEH)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/CPENT')); ?>">Certified Penetration Tester (CPENT)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/professional-training')); ?>">Custom Professional Training for Fresh Graduates</a></li>
        </ul>
    </li>
    <li><a href="<?php echo e(url('/services/security-training/common/management')); ?>">Management</a>
        <ul>
            <li><a href="<?php echo e(url('/services/security-training/custom/ISACA')); ?>">ISACA-Curriculam-(CISA,CISM)</a></li>
            <li><a href="<?php echo e(url('/services/security-training/custom/CISSP')); ?>">CISSP</a></li>
        </ul>
    </li>
</ul><!-- /.sidebar__category -->
<?php /**PATH /home/securitypedia/righttime/resources/views/frontend/bd/services/st/custom/cmn.blade.php ENDPATH**/ ?>