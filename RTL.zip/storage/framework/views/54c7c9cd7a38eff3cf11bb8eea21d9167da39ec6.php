<h3 class="sidebar__title">Standard Implementation & Certification</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/pci-dss')); ?>">Payment Card Industry Data Security Standards</a></li>
    <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/iso')); ?>">International Organization for Standardization-ISO</a></li>
    <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/CMMI')); ?>">CMMI</a></li>
    <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/SCIA')); ?>">SWIFT CSP Independent Assesment</a></li>
    <li><a href="<?php echo e(url('aus/services/standard-implementation-certification/data-center')); ?>">TIA 942 for Data Center</a></li>
</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/aus/services/sic/common.blade.php ENDPATH**/ ?>