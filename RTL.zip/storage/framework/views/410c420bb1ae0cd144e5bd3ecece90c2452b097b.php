<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title'); ?>
        Information Technology Audit
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('https://wallpaperaccess.com/full/1892752.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                <li><a href="<?php echo e(url('/services/auditing')); ?>">Auditing</a></li>
                <li>Information Technology Audit</li>
            </ul>
            <h2 class="page-header__title">Information Technology Audit</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->

    <section class="section-padding--bottom section-padding--top">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">


                    <h3 style="color:orange;" class="blog-card-one__title blog-details__title">Information Technology Audit</h3>
                    <div class="blog-details__content">
                        <p>An IT audit is a review and assessment of a company's information technology operations, policies, and infrastructure. Information technology audits determine whether IT controls safeguard corporate resources, guarantee data integrity, and are consistent with the overarching objectives of the company.</p>
                            <br><br><br><br><br><br><br><br><br><br>
                    </div><!-- /.blog-details__content -->


                </div><!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    <div class="sidebar">
                        <div class="sidebar__item sidebar__item--category">
                            <?php echo $__env->make('frontend.bd.services.auditing.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div><!-- /.sidebar__item -->
                    </div><!-- /.sidebar -->
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.bd.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/bd/services/auditing/ita.blade.php ENDPATH**/ ?>