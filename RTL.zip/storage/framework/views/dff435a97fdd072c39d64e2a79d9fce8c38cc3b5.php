<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('title'); ?>
        Project-Details
    <?php $__env->stopSection(); ?>

    <div class="page-header">
        <div class="page-header__bg"
             style="background-image: url(<?php echo e(asset('frontend/assets/images/background/page-header-bg-1-1.jpg')); ?>);"></div>
        <!-- /.page-header__bg -->
        <div class="container">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="index.html">Home</a></li>
                <li>Project</li>
            </ul>
            <h2 class="page-header__title">Project Details</h2><!-- /.page-header__title -->
        </div><!-- /.container -->
    </div><!-- /.page-header -->

    <section class="project-details section-padding--bottom section-padding--top">
        <div class="container">
            <div class="project-details__image">
                <img src="<?php echo e(asset('frontend/assets/images/projects/partners-d-1-1.jpg')); ?>" alt="">
            </div><!-- /.partners-details__image -->
            <div class="project-details__info">
                <div class="project-details__info__item">
                    <h4 class="project-details__info__title">Clients:</h4>
                    <p class="project-details__info__text">David Jackson</p><!-- /.partners-details__info__text -->
                </div><!-- /.partners-details__info__item -->

                <div class="project-details__info__item">
                    <h4 class="project-details__info__title">Category:</h4>
                    <p class="project-details__info__text"><a href="#">IT</a>, <a href="#">Technology</a></p>
                    <!-- /.partners-details__info__text -->
                </div><!-- /.partners-details__info__item -->
                <div class="project-details__info__item">
                    <h4 class="project-details__info__title">Date:</h4>
                    <p class="project-details__info__text">28 July, 2022</p><!-- /.partners-details__info__text -->
                </div><!-- /.partners-details__info__item -->
                <div class="project-details__info__item">
                    <h4 class="project-details__info__title">Value:</h4>
                    <p class="project-details__info__text">87,000 USD</p><!-- /.partners-details__info__text -->
                </div><!-- /.partners-details__info__item -->
                <div class="project-details__info__item">
                    <div class="project-details__info__social">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div><!-- /.partners-details__info__social -->
                </div><!-- /.partners-details__info__item -->
            </div><!-- /.partners-details__info -->
            <h3 class="project-details__title">Data Recovery Analysis</h3><!-- /.partners-details__title -->
            <div class="project-details__content">
                <p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum
                    quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes
                    port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is
                    simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the ndustry
                    standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
                    scrambled it to make a type specimen book. It has survived not only five centuries. Lorem Ipsum
                    is simply dummy text of the new design printng and type setting Ipsum Take a look at our round
                    up of the best shows coming soon to your telly box has been the is industrys. When an unknown
                    printer took a galley of type and scrambled it to make a type specimen book. It has survived not
                    only five centuries, but also the leap into electronic typesetting, remaining essentially
                    unchanged. </p>
                <p>Lorem Ipsum has been the ndustry standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a type specimen book. It has survived not
                    only five centuries. Lorem Ipsum is simply dummy text of the new design printng and type setting
                    Ipsum Take a look at our round up of the best shows coming soon to your telly box has been the
                    is industrys.</p>
                <ul class="project-details__list">
                    <li>
                        <i class="fa fa-check-circle"></i>
                        Lorem Ipsum generators on the Internet tend uses a dictionary.
                    </li>
                    <li>
                        <i class="fa fa-check-circle"></i>
                        The majority have alteration in some form of over 200 Latin words.
                    </li>
                    <li>
                        <i class="fa fa-check-circle"></i>
                        There are many variations of passages of available slightly.
                    </li>
                </ul><!-- /.partners-details__list -->
            </div><!-- /.partners-details__content -->
        </div><!-- /.container -->
    </section><!-- /.partners-details -->

    <div class="project-nav">
        <div class="container">
            <div class="project-nav__inner">
                <a href="#">
                    <i class="icon-left-arrow"></i>
                    Previous
                </a>
                <a href="#">
                    Next
                    <i class="icon-right-arrow"></i>
                </a>
            </div><!-- /.partners-nav__inner -->
        </div><!-- /.container -->
    </div><!-- /.partners-nav -->


    <section class="section-padding--top section-padding--bottom">
        <div class="container">
            <div class="section-title text-center">
                <p class="section-title__text">similar projects</p><!-- /.section-title__text -->
                <h2 class="section-title__title">Check We Have Similar <br>
                    IT Projects</h2><!-- /.section-title__title -->
            </div><!-- /.section-title -->
            <div class="owl-carousel thm-owl__carousel" data-owl-options='{
					"loop": true,
					"autoplay": true,
					"autoplayTimeout": 5000,
					"autoplayHoverPause": true,
					"smartSpeed": 700,
					"items": 1,
					"margin": 0,
					"nav": false,
					"dots": false,
					"responsive": {
						"0": {
							"items": 1,
							"margin": 0
						},
						"576": {
							"items": 2,
							"margin": 30
						},
						"992": {
							"items": 3,
							"margin": 30
						}
					}
				}'>
                <div class="item">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-1.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.item -->
                <div class="item">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-2.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.item -->
                <div class="item">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-3.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.item -->
                <div class="item">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-4.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.item -->
                <div class="item">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-5.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.item -->
                <div class="item">
                    <div class="project-card-one">
                        <div class="project-card-one__image">
                            <img src="<?php echo e(asset('frontend/assets/images/projects/partners-1-6.jpg')); ?>" alt="">
                        </div><!-- /.partners-card-one__image -->
                        <div class="project-card-one__content">
                            <div class="project-card-one__content__inner">
                                <p class="project-card-one__text">IT Technology Solution</p>
                                <h3 class="project-card-one__title"><a href="project-details.html">Data Recovery
                                        Analysis</a></h3><!-- /.partners-card-one__title -->
                                <a href="project-details.html" class="project-card-one__more">
                                    <i class="fa fa-angle-right"></i>
                                </a><!-- /.partners-card-one__more -->
                            </div><!-- /.partners-card-one__content__inner -->
                        </div><!-- /.partners-card-one__content -->
                    </div><!-- /.partners-card-one -->
                </div><!-- /.item -->
            </div><!-- /.owl-carousel -->
        </div><!-- /.container -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cs-partners\resources\views/frontend/partners/details.bank_nbfi.blade.php ENDPATH**/ ?>
