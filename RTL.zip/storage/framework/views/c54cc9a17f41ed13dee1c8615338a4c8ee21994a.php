<h3 class="sidebar__title">Custom</h3><!-- /.sidebar__title -->
<ul class="sidebar__category">
    <li><a href="<?php echo e(url('/services/security-training/penetration-testing')); ?>">Hands on Penetration Testing using Customized Labs and Multiple Licensed Tools</a>
    </li>

</ul><!-- /.sidebar__category -->
<?php /**PATH C:\xampp\htdocs\cs-project\resources\views/frontend/bd/services/st/custom/cmn.blade.php ENDPATH**/ ?>